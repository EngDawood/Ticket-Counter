
<html>
<head>
<script src="javacode.js"></script>
<title> TICKET COUNTER </title>
<LINK type="text/CSS" rel="stylesheet" href="cssproject.css"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="hover.css">
<style>
#immgg
{
	float:left;
	position: absolute;
}
#mainpagetitle
{
	size="1000";
	color="white";
}
</style>
</head>
<body>
	<center>
	<h1 id="mainpagetitle"><font face="BankGothic Lt BT"> TICKET COUNTER </h1>
	<hr>
	<br>
  <div class="w3-dropdown-hover">
  <button class="w3-btn w3-red">Movies</button>
  <div class="w3-dropdown-content w3-border">
    <a href="hollywood.html">Hollywood</a>
    <a href="#">Bollywood</a>
    <a href="#">International</a>
  </div>
</div>
  <div class="w3-dropdown-hover">
  <button class="w3-btn w3-red">Events</button>
  <div class="w3-dropdown-content w3-border">
    <a href="#">Fest</a>
    <a href="#">Concert</a>
    <a href="#">Theatre</a>
  </div>
</div>
  <div class="w3-dropdown-hover">
  <button class="w3-btn w3-red">Reviews</button>
  <div class="w3-dropdown-content w3-border">
    <a href="writereview.html">Write A Review</a>
    <a href="watchreview.html">Watch A Review</a>
  </div>
</div>
</center>
<br><br><br><a href="#"> 
<img src="44.jpg" width="500"></a>
<a href="#"> 
<img src="88.jpg" width="500"></a>
<a href="#"> 
<img src="5.jpg" width="500"></a>
	
</body>
</html>