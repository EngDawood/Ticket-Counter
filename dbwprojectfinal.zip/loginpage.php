<!doctype html><html>
<head>
	<title> TICKET COUNTER </title>
	<LINK type="text/CSS" rel="stylesheet" href="cssproject.css"/>
</head>
<body background ="wallpp.jpg">
<br><br><br>
<center>
	<table id="login_table"><tr><td><h1><font face="BankGothic Lt BT">TICKET COUNTER</h1></td></tr><tr><td><h2><center><font face="BankGothic Lt BT">Login Details</center></h2></td></tr>
	<tr><td><table>
		<form name="form2" action="login.php" method="post">
		<tr><td> <font face="BankGothic Lt BT">User Name:</td><td> <input type="text" id="txtFirstName" name="UserName"/></td></tr> 
		<tr><td><font face="BankGothic Lt BT"> Password:</td><td> <input type="password" name="Password" /></td></tr><tr><td></td><td> <input type="submit" Value="Login"/></td></tr></form>
		</table>
		<hr>
		<center>
		<center>
		<h2><font face="BankGothic Lt BT">New to Ticket Counter?</h2>
		<table>
		<tr><td> <button><a href="signup.html">Sign Up</a></button></td></tr>
	</table>
	</center>
</body>
</html>